/**
 * Created by fanzhang on 7/9/15.
 */


//--- functions ---

function renderSlide(slide){
    var slideContainer = $('#slideContent');
    for(var i=0;i<slide.content.length;i++){
    }
}