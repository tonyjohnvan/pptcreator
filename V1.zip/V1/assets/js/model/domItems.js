/**
 * Created by fanzhang on 6/10/15.
 */

var rightMenu =
    '<div class="custom-right-menu">\
        <ul class="dropdown-menu navbar-inverse op-nav-drop-down" role="menu">\
            <li><a onclick="addTextField();">Add Text</a></li>\
            <li><a onclick="">Delete Selected Text</a></li>\
            <li class="divider"></li>\
            <li class="dropdown-header">Report</li>\
            <li><a onclick="">New Slide</a></li>\
            <li><a onclick="">Delete Current Slide</a></li>\
        </ul>\
    </div>';